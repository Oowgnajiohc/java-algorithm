package interface1;

public interface InterfaceAnimal {
    int DEFUALT_EYE_COUNT = 2;
    void sound();
    void move();
    void introduce();

}
